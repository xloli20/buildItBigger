package com.example.javajokeslib;

public class Jokes {
}
